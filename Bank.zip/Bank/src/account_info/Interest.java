package account_info;
import java.io.*;
import java.util.*;
import java.math.*;

public class Interest {
    Scanner scanner = new Scanner(System.in);
    public static double interest_rate = 3;
    public void change_interest_rate()
    {
        System.out.println(">>>Enter new interest rate: ");
        double rate = scanner.nextDouble();
        interest_rate = rate;
    }
    public static double getInterestRate()
    {
        return interest_rate;
    }
    public static double update_balance_interest(double currnt_balance)
    {
        double amount_add = currnt_balance*(interest_rate/100);
        double new_balance;
        new_balance = Transaction.update_balance(currnt_balance,amount_add);
        return new_balance;
    }
}
