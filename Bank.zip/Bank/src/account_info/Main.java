package account_info;

import account_info.*;
import java.io.*;
import java.util.*;
import java.math.*;
public class Main {

    public static void trans(Account[] arr) {
        Scanner scanner = new Scanner(System.in);
        Transaction transaction = new Transaction();
        while (true) {
            System.out.println("*****Transaction*****\n>>>Enter Account Number\n");
            int acc_number = scanner.nextInt();
            int index = Account.index_no(arr, acc_number);
            System.out.println(">>>Select Transaction\n1.Deposit\n2.Withdraw\n3.Transfer\n>>>Enter 0 for Main Menu");
            int choice = scanner.nextInt();
            if (choice == 1) {
                transaction.deposit(arr[index]);
            }
            if (choice ==2)
            {
                transaction.withdraw(arr[index]);
            }
            if (choice ==3)
            {
                Transaction.Transfer transferinf =transaction.transfer(arr[index]);
                arr[index].setBalance(transferinf.getSender_balance());
                if(transferinf.getStatus()==0)
                {
                    continue;
                }
                if (transferinf.getStatus()==1)
                {
                    System.out.println(">>>Enter Receiver's Account Number");
                    int r_acc_number = scanner.nextInt();
                    int index_r = Account.index_no(arr, r_acc_number);
                    double fnew = Transaction.up(arr[index_r],transferinf.getAmount());
                    arr[index_r].setBalance(fnew);
                    System.out.println("Transfer Successful");
                    System.out.println("New Balance: " +arr[index].getBalance());
                    System.out.println("New Balance: " +arr[index_r].getBalance());
                }

            }
            if (choice == 0)
            {
                break;
            }
        }
    }

}
