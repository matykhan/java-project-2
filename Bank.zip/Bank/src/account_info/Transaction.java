package account_info;
import java.io.*;
import java.util.*;
import java.math.*;

public class Transaction  {
    Scanner  c = new Scanner(System.in);



    public void deposit(Account ac) {
        double amount = 0, new_balance;
        double curr_balance = ac.getBalance();
        System.out.println("Enter Amount to Deposite:\n");
        while (true) {
            amount = c.nextDouble();
            if (amount > 0) {
                curr_balance += amount;
                new_balance = curr_balance;
                System.out.println("Amount deposited Successfully");
                break;
            } else {
                System.out.println("Please Enter Valid Amount");
                continue;
            }
        }
        ac.setBalance(new_balance);
        System.out.println("New Balance :" + ac.getBalance());

    }

    public void withdraw(Account ac) {
        double amount = 0, new_balance = 0;
        double curr_balance = ac.getBalance();

        if (ac.type == 1) {
            while (true) {
                System.out.println("Enter Amount to Withdraw");
                amount = c.nextDouble();
                if ((curr_balance - amount) >= 100 && amount > 0) {
                    curr_balance -= amount;
                    new_balance = curr_balance;
                    System.out.println("Transaction Successful");
                    break;
                }
                if ((curr_balance - amount) < 100 && amount > 0) {
                    System.out.println("Invalid Transaction\nInsufficient Remaining Balance");
                    System.out.println(">>>Enter 0 to Cancel the Transaction\n>>>Enter 1 to continue the Transaction");
                    int choice = c.nextInt();
                    if (choice == 0) {
                        new_balance = curr_balance;
                        break;
                    }
                    if (choice == 1) {
                        continue;
                    } else {
                        System.out.println("Invalid Choice\n");
                        continue;
                    }

                } else {
                    System.out.println("Invalid Amount");
                    continue;
                }

            }
        }

        if (ac.type == 2) {
            while (true) {
                System.out.println("Enter Amount to Withdraw");
                amount = c.nextDouble();
                if (curr_balance >= amount && amount > 0) {
                    curr_balance -= amount;
                    new_balance = curr_balance;
                    System.out.println("Transaction Successful");
                    break;
                }
                if (curr_balance < amount && amount > 0) {
                    System.out.println("Insufficient Balance");
                    System.out.println(">>>Enter 0 to Cancel the Transaction\n>>>Enter 1 to continue the Transaction");
                    int choice = c.nextInt();
                    if (choice == 0) {
                        new_balance = curr_balance;
                        break;
                    }
                    if (choice == 1) {
                        continue;
                    } else {
                        System.out.println("Invalid Choice\n Transaction Canceled.");
                        new_balance = curr_balance;
                        break;
                    }
                } else {
                    System.out.println("Please Insert Valid Amount");
                    continue;
                }
            }
        }
        ac.setBalance(new_balance);
        System.out.println("New Balance :" + ac.getBalance());
    }
    public static double update_balance(double curr_balance,double amount )
    {
        double new_balance = curr_balance+amount;
        return new_balance;
    }
    public class Transfer  {
        public double sender_balance;
        public double amount;
        public int status;

        public Transfer(double x, double y,int status)
        {
            this.sender_balance = x;
            this.amount = y;
            this.status = status;
        }
        public double getSender_balance()
        {
            return sender_balance;
        }
        public double getAmount()
        {
            return amount;
        }
        public int getStatus(){return status;}


    }

    public Transfer transfer(Account ac) {
        double amount = 0, new_balance = 0;
        double curr_balance = ac.getBalance();
        int sta=0;
        if (ac.type == 1) {
            while (true) {
                System.out.println("Enter Amount to Transfer");
                amount = c.nextDouble();
                if ((curr_balance - amount) >= 100 && amount > 0) {
                    new_balance = curr_balance - amount;
                    sta =1;
                    break;
                }
                if ((curr_balance - amount) < 100 && amount > 0) {
                    System.out.println("Invalid Remaining Balance.\nRemaining Balance Can't be less tha $100");
                    System.out.println(">>>Enter 0 to Cancel Transfer\n>>>Enter 1 to continue Transfer");
                    int choice = c.nextInt();
                    if (choice == 0) {
                        System.out.println("Transfer Canceled");
                        new_balance = curr_balance;
                        break;
                    }
                    if (choice == 1) {
                        continue;
                    }
                } else {
                    System.out.println("Please Enter Valid Amount");
                }
            }
        }
        if (ac.type == 2) {
            while (true) {
                System.out.println("Enter Amount to Transfer");
                amount = c.nextDouble();
                if (curr_balance >= amount && amount > 0) {
                    new_balance = curr_balance - amount;
                    sta =1;
                    break;
                }
                if (curr_balance < amount && amount > 0) {
                    System.out.println("Insufficient Balance");
                    System.out.println(">>>Enter 0 to Cancel Transfer\n>>>Enter 1 to continue Transfer");
                    int choice = c.nextInt();
                    if (choice == 0) {
                        System.out.println("Transfer Canceled");
                        new_balance = curr_balance;
                        break;
                    }
                    if (choice == 1) {
                        continue;
                    }
                } else {
                    System.out.println("Please Enter Valid Amount");
                }
            }
        }
        return new Transfer(new_balance, amount,sta);

    }
    public static double up(Account ac,double amount)
    {
        double fnew = ac.getBalance()+amount;
        return fnew ;
    }
}
