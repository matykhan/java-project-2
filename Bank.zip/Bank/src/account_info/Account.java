package account_info;
import java.io.*;
import java.util.*;
import java.math.*;

public class Account  {
    public String name;
    public double amount;
    public double balance=0;
    public int account_number;
    public int type;
    Scanner c = new Scanner(System.in);

    public void create_account() {
        try {
            int choice = 0;
            double dp;
            System.out.println("Create New Account");
            System.out.println("Choose Account Type:\n 1.Savings Account \n 2.Current Account\n");
            choice = c.nextInt();
            type = choice;
            c.nextLine();
            System.out.println("Enter Your Name: ");
            name = c.nextLine();
            System.out.println("Enter Account Number: ");
            account_number = c.nextInt();
            while (true) {
                System.out.println("Deposit Minimum of $100  to Create Account\nEnter the Amount you want to Deposit");
                dp = c.nextInt();
                if (dp >= 100) {
                    balance = dp;
                    System.out.println("Account Created Successfully");
                    System.out.println("Account Holder Name: " + this.name);
                    System.out.println("Account Number: " + this.account_number);
                    System.out.println("Your account Balance: " + this.balance);
                    if (this.type ==1) {
                        System.out.println("Account Type: Savings");
                    }
                    if (this.type ==2)
                    {
                        System.out.println("Account Type: Current");
                    }
                    break;
                } else {
                    System.out.println("You Have to deposite minimum $100");
                    continue;
                }
            }
        }
        catch (Exception e)
        {

        }
    }
    public void setBalance(double balance)
    {
        this.balance = balance;
    }
    public double getBalance()
    {
        return balance;
    }
    public void account_information()
    {
        System.out.println("Account Holder Name: " + this.name);
        System.out.println("Account Number: " + this.account_number);
        System.out.println("Your account Balance: " + this.balance);
        if (this.type ==1) {
            System.out.println("Account Type: Savings");
        }
        if (this.type ==2)
        {
            System.out.println("Account Type: Current");
        }
    }
    public int getAccount_number()
    {
        return account_number;
    }
    public static int index_no(Account[] arr,int ac_num)
    {
        int indx = 0;
        for(int i = 0;i<arr.length;i++)
        {
            Account ac = new Account();
            ac = arr[i];
            if (ac_num == ac.getAccount_number())
            {
                indx =i;
                break;
            }
            else
            {
                continue;
            }
        }
        return indx;
    }


}
