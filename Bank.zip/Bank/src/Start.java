import account_info.*;
import java.io.*;
import java.util.*;
import java.math.*;
public class Start {
    public static void main(String[] args) {
        int maximum_account = 10, number_of_account = 0;
        System.out.println("********Welcome********");
        Scanner scanner = new Scanner(System.in);
        Account accounts[] = new Account[maximum_account];
        while (true) {
            int choice;
            System.out.println("Selecet An Operation\n1.Add a new Account\n2.Account Information(Need account Number)\n3.Number of Active Account\n4.Update Balance of a Savings Account For yearly interest\n5.Change interest Rate\n6.Transaction(Deposit or Withdraw or Transfer\n>>>Enter 0 to Exit");
            choice = scanner.nextInt();
            if (choice == 1) {
                System.out.println("*****Account Creation*****");
                Account ac = new Account();
                ac.create_account();
                accounts[number_of_account]=ac;
                number_of_account++;
                System.out.println(number_of_account);
                System.out.println("*****************************************\n\n");
                continue;
            }
            if (choice == 2) {
                System.out.println("***Account Information**\n>>>Enter Account Number");
                int acc_number = scanner.nextInt();
                int index = Account.index_no(accounts,acc_number);
                accounts[index].account_information();
                System.out.println("*****************************************\n\n");
                continue;
            }
            if (choice ==3)
            {
                System.out.println(number_of_account);
                System.out.println("*****************************************\n\n");
                continue;
            }
            if (choice ==4)
            {
                System.out.println("***Account Information**\n>>>Enter Account Number");
                int acc_number = scanner.nextInt();
                int index = Account.index_no(accounts,acc_number);
                double new_bal = Interest.update_balance_interest(accounts[index].balance);
                accounts[index].setBalance(new_bal);
                System.out.println("Balance Updated\nNew Balance :" + accounts[index].getBalance());
                System.out.println("*****************************************\n\n");
                continue;
            }
            if (choice ==5)
            {
                System.out.println("Current interest Rate: "+ Interest.getInterestRate());
                System.out.println(">>>Enter new Interest Rate:\n");
                Interest.interest_rate = scanner.nextDouble();
                System.out.println("Interest Rate Changed Successfully\nNew Interest Rate: "+ Interest.getInterestRate());
                continue;
            }
            if (choice ==6)
            {
                Main.trans(accounts);
                continue;
            }
            if(choice == 0)
            {
                break;
            }
        }
    }
}
